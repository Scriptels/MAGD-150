let mX;
let mY;
let logged = false;
let programRunning = false;
let active_tab = false;
let close_tab = false;
let app_presets = [x=35,y=35,tsize=10,color_ = "white",];

function SetupBackground() {
  colorMode(RGB, 250);
  for (let x = 26; x < 375; x += 1.2) {
    for (let y = 50; y < 275; y += 1.13) {
      stroke(x, y, 0);
      point(x, y);
    }
  }
}

function LoginScreen() {
  fill("white");
  stroke("black");
  rect(148,210,100,25);
  text("Welcome back, User",140,195);
   text("Press the login button, and the L key",105,265);
  fill("black");
  text("LOGIN",178, 227);
}

function setup() {
  createCanvas(400, 400);
  background(300);
  fill("black")
  
  // -- Screen edges
  rect(1,25,25,275);
  rect(374,25,25,270);
  rect(1,25,399,25);
  rect(1,275,399,25);
  
  // -- PC background
  SetupBackground()
  
  // -- Monitor
  fill("#929292")
  stroke("#929292")
  rect(1,25,22,275,2);
  rect(378,25,22,275);
  rect(1,25,399,22);
  rect(1,278,399,25);
  
  // -- Stand
  rect(180,300,35,30);
  ellipse(197,345,125,30);
  
  LoginScreen();
}

function LoadApps() {
  stroke("white");
  fill("#AFAFAF");
  
  // -- Internet
  rect(55,80,x,y);
  fill("#4451A3")
  ellipse(68,92,12,12);
  ellipse(82,102,9,9);
  fill("white");
  textSize(10);
  text("The internet", 46,130);
  
  // - Sign out
}

function SetCloseTab() {
  close_tab = true;
  return close_tab;
}

function SetTabActivity(){
  active_tab = true;
  return active_tab;
}
function ClearScreen() {
  erase();
  rect(26, 50, 348, 225);
  noErase();
}

function LoadTab() {
  fill("white");
  stroke(0)
  rect(85,72,230,170,2)
  
  // -- Buttons
  fill("red");
  rect(290,72,25,25);
  fill("white");
  textSize(18);
  text("X",296,91)
}

function LoadProgram(openedApp) {
  if (openedApp === "The internet") {
    console.log("program running is internet");
    LoadTab();
    
  }
}

function mouseClicked() {
  mX = mouseX;
  mY = mouseY;
  
  if ((mX > 148) && (mX < 148+100) && (mY > 210) && (mY < 210+25)) {logged = true; return logged;}
}

function mousePressed() {
   mX = mouseX;
   mY = mouseY;
  
   if ((mX > 55) && (mX < 55+x) && (mY > 80) && (mY < 80+y)) {LoadProgram("The internet"); SetTabActivity()} 
  
  else if((mX > 290) && (mX < 290+25) && (mY > 72) && (mY < 72+25)) {SetCloseTab(); console.log("closing")}
}



function draw() {
  
  if (keyIsPressed) {
    if (key == "l") {
      if (logged == true) {
        ClearScreen()
        SetupBackground();
        LoadApps();
        logged = false;
        return logged;
      }
    }
  }
  
  if (active_tab === true) {
    active_tab = false;
    LoadTab();
  }
  
  if (close_tab === true) {
    close_tab = false;
    ClearScreen(); 
    SetupBackground();
    LoadApps();
  }
}

// This could honestly be like an actual more functional computer if a lot more work went into it.