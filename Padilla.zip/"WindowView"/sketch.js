function setup() {
  createCanvas(700, 500);
  angleMode(DEGREES);
}

function DrawWalls(){
  for (let i = 260; i <= 700; i+= 30) {
    rect(i, 0, 10, 500);
  }
  
  for (let x = 50; x <=230; x +=30) {
    rect(x, 0, 10, 50);
    rect(x, 380, 10, 120);
  }
}

function setupCanvas() {
  background("#94CAD9");
  fill("yellow");
  circle(80, 120, 90);
  fill("#EDE8D7");
  //walls
  rect(0,0,40,500);
  rect(250,0,700,500);
  rect(41,0,208,50);
  rect(41,380,208,150);
  //stripes
  fill("#BEF5B1")
  rect(20,0,10,500);
  rect(50,0,10,50);
  rect(50,380,10,120);
  rect(260,0,10,500);
  DrawWalls();
  fill("#754B3D");
  rect(39,35,10,350);
  rect(240,35,10,350);
  rect(35,35,220,25);
  rect(35,380,220,25);
}


function Console(){}

function draw() {
  setupCanvas();
  fill("grey");
  circle(353,248,200)
  push();
  let clocktime = 0;
  fill(0)
  for (let angle=0; angle <= 360; angle += 30) {
      push();                       
      translate(width/2, height/2);
      rotate(angle);
      stroke(0);
      strokeWeight(20);
      line(0, 0, 10, 0);
      strokeWeight(1);  
      clocktime += 1;
      text(clocktime, 80, 0);
      pop();       
  }
  
  translate(width/2, height/2);
  rotate(frameCount);
  stroke(255);
  strokeWeight(5);
  line(0, 0, 70, 0);
  
  pop();

}