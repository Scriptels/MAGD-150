// Variables - 
let colorLibrary = ["pink","blue","red","purple","orange","grey"];
let currentStroke = "white"
let currentStrokeweight = 5



function setup() {
  createCanvas(1050, 400);
  background(60);
 
}

function mouseClicked() {
  console.log("mouse clicked");
  
  if (currentStrokeweight < 40) {
    currentStrokeweight += 5; }
  else if (currentStrokeweight > 20 ) {
    currentStrokeweight = 5;}
}

function draw() {
  stroke(currentStroke);
  strokeWeight(currentStrokeweight);
  
  for (let i = 100; i < 1000; i += 100) {
   line(i, 350, i, 100) }

  if (mouseIsPressed === true) {
    currentStroke = random(colorLibrary)
  }
}