function setup() {
  createCanvas(400, 400);
  stroke('grey');
  strokeWeight(35);
}

function draw() {
  background(220);
  stroke('grey');
  strokeWeight(35);
  point(250,200);
  ellipse(110,90,80,80);

}